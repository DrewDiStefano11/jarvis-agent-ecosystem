---
name: Cybernetic AI OS
colors:
  surface: '#10131d'
  surface-dim: '#10131d'
  surface-bright: '#363944'
  surface-container-lowest: '#0b0e18'
  surface-container-low: '#191b26'
  surface-container: '#1d1f2a'
  surface-container-high: '#272935'
  surface-container-highest: '#323440'
  on-surface: '#e1e1f1'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e1e1f1'
  inverse-on-surface: '#2e303b'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#d3fbff'
  on-secondary: '#00363a'
  secondary-container: '#00eefc'
  on-secondary-container: '#00686f'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00a572'
  on-tertiary-container: '#00311f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#7df4ff'
  secondary-fixed-dim: '#00dbe9'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f54'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#10131d'
  on-background: '#e1e1f1'
  surface-variant: '#323440'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: '0'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: '0'
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.25rem
  margin: 1rem
  margin-desktop: 1.75rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system embodies the command layer of next-generation enterprise autonomous intelligence. It combines deep-space cosmic midnight backdrops with high-luminance, electric phosphor telemetry to evoke total operational omniscience, supreme technological precision, and effortless executive mastery.

The visual style fuses **Futuristic Glassmorphism** and **Cybernetic HUD Telemetry**. Surfaces are rendered as multi-layered, polarized frosted sheets floating within an infinite cosmic void. Micro-borders carry directional energy pulses, while high-contrast data visualizations, holographic rings, and tactile phosphor status indicators guide high-velocity decision-making. 

The emotional response is calculated, authoritative, and exhilarating: users do not merely browse a dashboard; they command an autonomous fleet of intelligent cybernetic agents.

## Colors

The palette is engineered around dark-mode-first deep cosmic radiance:

- **Primary (`#8b5cf6` / `#9d65ff`):** Cyber Violet. Anchors the primary action states, brand crests, selected rail indicators, and master synthetic intelligence nodes.
- **Secondary (`#00f0ff` / `#38bdf8`):** Electric Neon Cyan. Represents real-time data flow, computational pipelines, progress meters, and dynamic sparklines.
- **Tertiary (`#10b981`):** Emerald Pulse. Signifies autonomous health, operational stability, successful executions, and verified agent runtime states.
- **Warning / Alert (`#f59e0b` / `#ef4444`):** Solar Amber and Laser Crimson. Reserved for approval gates, high-priority human-in-the-loop interventions, and operational bottlenecks.
- **Neutral Core (`#060812` / `#0a0e1c` / `#11162b`):** Cosmic Midnight Obsidian. Creates an infinite-depth canvas with specialized surface tiers that absorb ambient light while letting glowing telemetry shine with zero chromatic fatigue.

## Typography

The typographical structure balances sharp cybernetic attitude with uncompromising operational readability:

- **Display & Headlines (Space Grotesk):** Engineered with geometric mechanical incisions and futuristic proportions. Used for workspace banners, master module headers, and KPI numerals.
- **Interface & Reading Body (Plus Jakarta Sans):** Provides friendly, hyper-legible ergonomics with high x-height for multi-line agent instructions, long-form system logs, and dense operational summaries.
- **Telemetry & Metadata Labels (JetBrains Mono):** High-precision monospaced type used for execution timestamps, runtime performance values, keybindings (`⌘K`), agent roles, and status tags. All telemetry labels enforce tabular lining figures to ensure zero vertical jitter during real-time streaming updates.

## Layout & Spacing

The layout model adopts a modular, high-density HUD matrix based on an 8pt architectural rhythm with 4pt micro-subdivisions:

- **Desktop Shell:** Employs a persistent navigation flight rail (compact 64px collapsed, 220px expanded), an omni-present tactical header (`56px` height) with global system telemetry and command palette (`⌘K`), followed by an asymmetric 12-column grid.
- **Card Clustering:** Primary modules stack in high-efficiency bento formats. Cards leverage `space-lg` inner padding and `gutter-desktop` (20px) separation to sustain structural density without cognitive clutter.
- **Mobile Adaptations:** The interface transitions to a unified vertical single-column view with a thumb-zone bottom docking bar (`64px` height). Nested table data reflows into condensed modular stat cards with horizontal pill swiping.

## Elevation & Depth

Visual hierarchy is manifested through polarized frosted glass, luminescent boundary refraction, and ambient neon back-glows:

- **Surface Tier 0 (Cosmic Floor):** `#060812` background illuminated with subtle radial gradients of deep indigo (`#171938`) and cosmic purple (`#1d123a`) with low opacity (15–25%).
- **Surface Tier 1 (Vessel Containers):** Background `#0a0e1c` at 70% opacity, layered with `backdrop-filter: blur(20px)` and framed by a 1px composite outline (`rgba(255, 255, 255, 0.08)` top/left and `rgba(139, 92, 246, 0.25)` bottom/right).
- **Surface Tier 2 (Interactive Modules & Hover Cards):** Background `#12182c` at 85% opacity, paired with an inner top hairline `inset 0 1px 0 rgba(255, 255, 255, 0.15)` and an ambient exterior glow: `0 8px 32px -4px rgba(0, 0, 0, 0.6), 0 0 16px rgba(139, 92, 246, 0.15)`.
- **Surface Tier 3 (Modals, Flight Command Menus, Overlays):** Background `#161f38` at 95% opacity with an intense cyber halo: `0 24px 64px rgba(0, 0, 0, 0.8), 0 0 24px rgba(0, 240, 255, 0.2)`.

## Shapes

The design system standardizes on **Rounded (Level 2)** geometry:

- Standard cards, interactive panes, and dashboards feature `rounded-lg` (16px / `1rem`) contours, striking an ergonomic equilibrium between clinical cybernetics and polished consumer software.
- Sub-components such as buttons, telemetry pills, status tags, and avatar frames utilize `0.5rem` (8px) corners to preserve compact modular tension.
- Circular treatment (100% border radius) is reserved exclusively for agent status indicators, holographic telemetry donut graphs, user avatars, and orb command rings.

## Components

### Buttons & Interactive Triggers
- **Primary Cyber Action:** Background linear gradient from `#8b5cf6` to `#6d28d9` with an ultra-thin top highlight. State changes trigger an increased neon drop shadow (`0 0 18px rgba(139, 92, 246, 0.5)`).
- **Secondary Ghost Action:** Translucent dark obsidian container (`rgba(255, 255, 255, 0.04)`), bordered with `rgba(255, 255, 255, 0.12)`. On hover, border shifts to electric cyan (`#00f0ff`) with `rgba(0, 240, 255, 0.08)` surface tint.
- **Icon Telemetry Buttons:** `36x36px` square containers with `0.5rem` radius, housing monospaced or vectorized micro-symbols with centered alignment.

### Telemetry Status Chips & Badges
- Constructed with high-contrast semi-transparent color fills (`10%` opacity of the target status color) coupled with a matching 1px border.
- Equipped with a leading 6px pulsing LED dot:
  - **Online / Healthy:** Emerald (`#10b981`) with `box-shadow: 0 0 8px #10b981`.
  - **Active / Processing:** Cyan (`#00f0ff`) with an automated slow breathe animation.
  - **Pending Gate / Warning:** Amber (`#f59e0b`) with steady glow.

### Command HUD Cards & Metric Tiles
- Multi-layered glass cards featuring structured header bands: category badge on left, status indicator or sparkline on right.
- High-visibility numerical readouts styled with Space Grotesk, accompanied by subtext micro-deltas indicating week-over-week velocity.
- Micro sparklines styled with neon strokes (`2px`), transparent zero-fill gradients, and illuminated endpoint coordinates.

### Inputs & Omnisearch Command Bar
- Field containers feature deep obsidian recessed fill (`#070a14`) with a soft inset shadow.
- Border shifts from passive glass gray (`rgba(255, 255, 255, 0.1)`) to active radiant cyber violet (`#8b5cf6`) with a 3px diffused outer focus glow.
- Right-aligned keyboard shortcut chip (`⌘K`) set in JetBrains Mono.

### Data Grid & Agent Process Lists
- Alternating subtle rows with transparent glass styling, separated by `1px solid rgba(255, 255, 255, 0.05)`.
- Checkboxes maintain a square `16x16px` form factor with `4px` corner radiuses, illuminated with solid violet fill and sharp check glyphs upon selection.
- Hovering over a row triggers an electric cyan left border accent strip (`2px width`) and a subtle background elevation shift.